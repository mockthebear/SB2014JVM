#include <stdio.h>
#include <stdint.h>

#include "definition.hpp"
#include "op_stack.hpp"



#ifdef __cplusplus
extern "C" {
#endif 

extern int _push(void *, char, void *);
extern int _pop(void *, void *);
extern int _iadd(void *);



#ifdef __cplusplus
}
#endif


union Float {
	float f;
	u4 i;
};

void teste_nasm1() {
	Value v[100];
	Value *top = v;
	int i;
	int temp;
	Float f;
	
	f.f = 34.23;
	i = 0x12345678;
	temp = _push(top, TYPE_INT, &i);
	top++;
	temp = _push(top, TYPE_FLOAT, &(f.f));
	top++;
	
	printf("%X [%d] %f\n", f.i, f.i, f.f);
	
	for(int i=0; i<5; i++)
		v[i].printnl();
}

void teste_iadd() {
	OperandStack op_stack(100);
	op_stack.iconst_0();
	op_stack.iconst_1();
	op_stack.iconst_2();
	op_stack.iconst_3();
	op_stack.iconst_4();
	op_stack.iconst_5();
	op_stack.print();
	
	/*
	printf("%08X\n",_iadd(op_stack.top--));
	printf("%08X\n",_iadd(op_stack.top--));
	printf("%08X\n",_iadd(op_stack.top--));
	*/
	op_stack.iadd();
	op_stack.print();
	op_stack.iadd();
	op_stack.print();
	op_stack.iadd();
	op_stack.print();
}

void teste_isub() {
	OperandStack op_stack(100);
	op_stack.iconst_0();
	op_stack.iconst_1();
	op_stack.iconst_2();
	op_stack.iconst_3();
	op_stack.iconst_4();
	op_stack.iconst_5();
	op_stack.print();
	
	/*
	printf("%08X\n",_iadd(op_stack.top--));
	printf("%08X\n",_iadd(op_stack.top--));
	printf("%08X\n",_iadd(op_stack.top--));
	*/
	op_stack.isub();
	op_stack.print();
	op_stack.isub();
	op_stack.print();
	op_stack.isub();
	op_stack.print();
}

void teste_op_stack1() {
	Float f = {123.34};
	OperandStack op_stack(100);
	Value v1('B', 0x12345678);
	Value v2('I', 222);
	Value v3('[', 333);
	Value v4('S', 444);
	Value v5;
	Value v6;
	
	op_stack.push_i(-123);
	op_stack.push_f(123.34);
	op_stack.print();
	
	float i1;
	//printf("out: %08X\n",_pop(op_stack.top-1, &i1));
	op_stack.pop_i(&i1);
	f.f = i1;
	printf("d3: %.4f\n",i1);
	op_stack.print();

}

void teste_op_stack_constante() {
	OperandStack op_stack(100);
	op_stack.iconst_m1();
	op_stack.iconst_0();
	op_stack.iconst_1();
	op_stack.iconst_2();
	op_stack.iconst_3();
	op_stack.iconst_4();
	op_stack.iconst_5();
	op_stack.fconst_0();
	op_stack.fconst_1();
	op_stack.fconst_2();
	op_stack.print();
}

int main() {

	teste_isub();
	
	return 0;
}


