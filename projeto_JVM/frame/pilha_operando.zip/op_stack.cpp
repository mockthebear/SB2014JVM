#include "op_stack.hpp"


extern "C" int _push(void *, char, void *);
extern "C" int _pop(void *, void *);
extern "C" int _iadd(void *);
extern "C" int _isub(void *);

#define DEV

/* CONSTRUTOR */
OperandStack::OperandStack(u2 m) {
	size = 0;
	max  = m;
	stack = new Value[max];
	top = &stack[0];
}

/* OPERACOES DO BYTE CODE */
void OperandStack::bipush(u1 in) {
	Value temp;
	temp.type  = 'B';
	temp.bytes = in;
	temp.printnl();
	if(in & 0x80) {
		temp.bytes |= 0xFFFFFF00;
		temp.printnl();
	}
	//push_i(in);
}

void OperandStack::sipush(u2 in) {
	Value temp;
	temp.type  = 'S';
	temp.bytes = in;
	temp.printnl();
	if(in & 0x8000) {
		temp.bytes |= 0xFFFF0000;
		temp.printnl();
	}
	//push_i(in);
}

void OperandStack::iconst_m1() {
	push_i(-1);
}

void OperandStack::iconst_0() {
	push_i(0);
}

void OperandStack::iconst_1() {
	push_i(1);
}

void OperandStack::iconst_2() {
	push_i(2);
}

void OperandStack::iconst_3() {
	push_i(3);
}

void OperandStack::iconst_4() {
	push_i(4);
}

void OperandStack::iconst_5() {
	push_i(5);
}

void OperandStack::fconst_0() {
	push_f(0.0F);
}

void OperandStack::fconst_1() {
	push_f(1.0F);
}

void OperandStack::fconst_2() {
	push_f(2.0F);
}

int OperandStack::iadd() {
	if(size < 2)
		return 0;
	top--;
	_iadd(top);
	size--;
}

int OperandStack::isub() {
	if(size < 2)
		return 0;
	top--;
	_isub(top);
	size--;
}



/* OPERACAO GERAL */
int OperandStack::push_i(int32_t i) {
#ifdef DEV
	printf("\npush\n");
	if(size == max) {
		printf("pilha cheio\n");
		return 0;
	}
#else
	if(size == max)
		return 0;
#endif
	_push(top, TYPE_INT, &i);
	top++;
	size++;
}

int OperandStack::push_f(float f) {
#ifdef DEV
	printf("\npush\n");
	if(size == max) {
		printf("pilha cheio\n");
		return 0;
	}
#else
	if(size == max)
		return 0;
#endif
	_push(top, TYPE_FLOAT, &f);
	top++;
	size++;
}

int OperandStack::pop_i(void *v) {
#ifdef DEV
	printf("\npop\n");
	if(size == 0) {
		printf("pilha vazio\n");
		return 0;
	}
#else
	if(size == 0)
		return 0;
#endif
	top--;
	_pop(top, v);
	size--;
}

void OperandStack::print() {
	printf("max: %d\n", max);
	printf("size: %d\n", size);
	
	for(int i=size-1; i>=0; i--) {
		printf("\t");
		stack[i].printnl();
	}
	printf("\tbase\n");
	
	
}





