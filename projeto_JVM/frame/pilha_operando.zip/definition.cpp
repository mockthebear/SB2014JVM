#include "definition.hpp"

extern "C" float _to_float(void *);

Value::Value() {
	type = 0;
	bytes = 0;
}

Value::Value(u1 t, u4 b) {
	type = t;
	bytes = b;
}

float Value::to_float(u4 bytes) {
	union {
		u4 b;
		float f;
	} temp;
	temp.b = bytes;
	return temp.f;
}

void Value::print() {
	printf("[%c] %08X ", type, bytes);
	switch(type) {
		case TYPE_INT:
			printf("int(%d)", bytes);
			break;
		case TYPE_FLOAT:
			printf("float(%f)", to_float(bytes));
			break;
		default:
			break;
	}
}

void Value::printnl() {
	print();
	printf("\n");
}
