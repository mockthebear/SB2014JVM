#ifndef OPERAND_STACK
#define OPERAND_STACK

#include <stdio.h>
#include <stdint.h>

#include "definition.hpp"

class OperandStack {
public:
	Value *stack;
	Value *top;
	u4 max;
	u4 size;

	OperandStack(u2);
	void bipush(u1);
	void sipush(u2);
	
	void iconst_m1();
	void iconst_0();
	void iconst_1();
	void iconst_2();
	void iconst_3();
	void iconst_4();
	void iconst_5();
	
	void fconst_0();
	void fconst_1();
	void fconst_2();
	
	int iadd();
	int isub();
	
	
	int push_i(int32_t);
	int push_f(float);
	int pop_i(void *);
	
	void print();
};

#endif
