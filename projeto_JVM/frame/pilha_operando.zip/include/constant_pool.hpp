#ifndef CONST_POOL
#define CONST_POOL

#include "definition.hpp"


typedef union {
	struct CONSTANT_Class_info {
		u2 name_index;
	} Class;
	struct CONSTANT_Reference_info {
		u2 class_index;
		u2 name_and_type_index;
	} Reference;
	struct CONSTANT_String_info {
		u2 string_index;
	} String;
	struct CONSTANT_Integer_info {
		u4 bytes;
	} Integer;
	struct CONSTANT_Float_info {
		u4 bytes;
	} Float;
	struct CONSTANT_Long_info {
		u4 high_bytes;
		u4 low_bytes;
	} Long;
	struct CONSTANT_Double_info {
		u4 high_bytes;
		u4 low_bytes;
	} Double;
	struct CONSTANT_NameAndType_info {
		u2 name_index;
		u2 descriptor_index;
	} NameAndType;
	struct CONSTANT_Utf8_info {
		u2 length;
		u1 *bytes;
	} Utf8;
} c_info;

typedef struct {
	u1 tag;
	c_info info;
} cp_info;

enum cp_tag { ZERO, TAG_UTF8, DOIS, TAG_INTEGER, TAG_FLOAT, TAG_LONG, 
			  TAG_DOUBLE, TAG_CLASS, TAG_STRING, TAG_FIELD, TAG_METHOD,
			  TAG_IMETHOD, TAG_NAMEANDTYPE};

#endif
