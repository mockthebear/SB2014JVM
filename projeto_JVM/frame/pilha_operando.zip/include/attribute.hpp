#ifndef ATTRIBUTE
#define ATTRIBUTE

#include "definition.hpp"

typedef struct  {
	u2 name_index;
	u4 length;
	u1 *info;
} attribute_info;

#endif
