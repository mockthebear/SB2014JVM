#ifndef CLASS_LOADER
#define CLASS_LOADER

#include <iostream>
#include <string.h>

#include "class.hpp"

class ClassLoader {
	public: 
	Class *newClass(char *);
	
};

#endif

